Moya code goes here

The filenames used here are just a suggestion of how to organize your Moya code
-- all files with the extension .xml will be read.
