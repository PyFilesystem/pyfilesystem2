This folder should contain templates for widgets defined in the library.
