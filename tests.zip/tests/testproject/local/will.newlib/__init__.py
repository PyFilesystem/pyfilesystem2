# Required if you want to distribute your library as a Python module
