Translations go here. Use the 'moya extract' command to create message
catalogs.


