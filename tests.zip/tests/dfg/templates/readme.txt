This folder contains site-wide templates, typically used to customize the look
and feel of the site.
