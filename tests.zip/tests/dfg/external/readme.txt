This folder should contain libraries that are external (i.e. authored
elsewhere).
The moya command line app installs libraries to this location.

NB. If you make local edits to these files, the moya command line app may end
up overwriting them!
