Static data (typically json files) may be placed here.
