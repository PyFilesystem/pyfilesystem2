The contents of this directory will be served as static files by the
moya.static library (including this file)!
If you have directory listing enabled, you can see what files are served by
visiting the /static/ url in your browser.
