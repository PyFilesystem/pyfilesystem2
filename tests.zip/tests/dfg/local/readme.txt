This folder should contain libraries that are local to the project, i.e.
authored by yourself or organization.
