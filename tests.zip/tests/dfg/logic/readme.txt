This folder contains the first XML files read by Moya, which will typically
contain one or more <server> declarations.
