This folder contains the 'site' library. The site library is for functionality
that is highly specific to the site, and is generally used to customize
functionality of other libraries.
